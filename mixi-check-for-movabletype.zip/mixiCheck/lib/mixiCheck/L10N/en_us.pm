package mixiCheck::L10N::en_us;

use strict;
use base qw( mixiCheck::L10N );
use vars qw( %Lexicon );

%Lexicon = ();

1;
